'use strict';

(window.location.href="#/Admin/Log.aspx")();
