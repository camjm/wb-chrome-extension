'use strict';

console.log('clear cache!!');
