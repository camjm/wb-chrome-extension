'use strict';

(function() {
  window.location.href="#/Admin/Log.aspx";
})();
