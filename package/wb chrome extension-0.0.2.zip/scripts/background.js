"use strict";!function(e,n){e.onInstalled.addListener(function(){n.onPageChanged.removeRules(void 0,function(){n.onPageChanged.addRules([{conditions:[new n.PageStateMatcher({pageUrl:{pathSuffix:"/Workbench.aspx"},css:["html[ng-app=wbApp]"]})],actions:[new n.ShowPageAction]}])})})}(chrome.runtime,chrome.declarativeContent);
//# sourceMappingURL=background.js.map
