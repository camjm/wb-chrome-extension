'use strict';

(function() {
  ClearCache();
})();
